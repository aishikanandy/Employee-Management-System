---Employee Management System---

---Objective:-

----The goal of this project is to create a database for an Employee Management System that manages employee information, departments, and salaries.
----We will demonstrate how to use subqueries to retrieve specific data and use functions to manipulate data.

CREATE DATABASE EmployeeDB; --Database creation
GO

USE EmployeeDB;
GO

--Creating Departments' table--

CREATE TABLE Departments
(
DepartmentID INT PRIMARY KEY IDENTITY(1,1),
DepartmentName NVARCHAR(100) NOT NULL
);

GO

--Creating 'Employees' table--

CREATE TABLE Employees
(
EmployeeID INT PRIMARY KEY IDENTITY(1,1),
FirstName NVARCHAR(50) NOT NULL,
LastName NVARCHAR(50) NOT NULL,
Email NVARCHAR(100) NOT NULL,
DepartmentID INT FOREIGN KEY REFERENCES Departments,
Salary DECIMAL(10, 2) NOT NULL
);

GO

---Insert sample data---


INSERT INTO Departments (DepartmentName)

VALUES

('Human Resources'),
('Finance'),
('IT'),
('Marketing'),
('Sales');

GO

INSERT INTO Employees (FirstName, LastName, Email, DepartmentID, Salary)

VALUES

('Amit', 'Sharma', 'amit.sharma@example.com', 1, 45000.00),   -- HR
('Riya', 'Singh', 'riya.singh@example.com', 1, 48000.00),      -- HR

('Karan', 'Patel', 'karan.patel@example.com', 2, 52000.00),    -- Finance
('Neha', 'Mehta', 'neha.mehta@example.com', 2, 60000.00),      -- Finance

('Sahil', 'Verma', 'sahil.verma@example.com', 3, 75000.00),    -- IT
('Aisha', 'Khan', 'aisha.khan@example.com', 3, 82000.00),      -- IT

('Vikram', 'Das', 'vikram.das@example.com', 4, 55000.00),      -- Marketing
('Tina', 'Roy', 'tina.roy@example.com', 4, 57000.00),          -- Marketing

('Rahul', 'Ghosh', 'rahul.ghosh@example.com', 5, 50000.00),    -- Sales
('Sneha', 'Pillai', 'sneha.pillai@example.com', 5, 53000.00);  -- Sales

GO

---Using Subqueries and Functions---

--1. Find employees earning above the average salary (subquery)

SELECT * FROM Employees

WHERE Salary>(SELECT AVG(Salary) FROM Employees);

GO

--2. Show the highest paid employee in each department

CREATE FUNCTION dbo.GetHighestSalary (@DepartmentName NVARCHAR(100))

RETURNS DECIMAL (10,2)

AS

BEGIN

DECLARE @MaxSalary DECIMAL (10,2)

SELECT @MAXSalary=MAX(Salary)

FROM Employees AS E

JOIN Departments AS D ON E.DepartmentID=D.DepartmentID

WHERE DepartmentName= @DepartmentName

RETURN @MaxSalary

END;

GO

--Query the function

SELECT E.EmployeeID, E.FirstName, E.LastName, D.DepartmentName, Salary FROM Employees AS E

JOIN Departments AS D ON E.DepartmentID=D.DepartmentID

WHERE E.Salary=dbo.GetHighestSalary(D.DepartmentName)

---Create a function to return full name---

CREATE FUNCTION dbo.FullName (@EmployeeID INT)

RETURNS NVARCHAR(100)

AS

BEGIN

DECLARE @FullName NVARCHAR(100);

SELECT @FullName= FirstName+' '+LastName

FROM Employees

WHERE EmployeeID=@EmployeeID

RETURN @FullName

END;

GO

--Use the function in query--

SELECT EmployeeID, dbo.FullName(EmployeeID) AS FullName, Email, Salary

FROM Employees;

GO

---Conclusion---

---In this project, we successfully created an EmployeeDB database, defined tables for employees and departments, and inserted sample data.
---We also used sub-query to find employees with above-average salaries, functions to find the deprtment wise highest paid employees, and FullName of the employees.

